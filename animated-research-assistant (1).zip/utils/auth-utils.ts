/**
 * Generates a cryptographically secure random nonce for use with Google One Tap
 * @returns A base64-encoded nonce string
 */
export function generateNonce(): string {
  if (typeof window === "undefined") {
    // Server-side fallback
    return Math.random().toString(36).substring(2, 15)
  }

  // Generate a random array of bytes
  const array = new Uint8Array(32)
  window.crypto.getRandomValues(array)

  // Convert to base64 string
  const nonce = btoa(String.fromCharCode.apply(null, Array.from(array)))

  // Hash the nonce for additional security
  return nonce
}

/**
 * Creates a SHA-256 hash of the nonce for verification
 * @param nonce The original nonce to hash
 * @returns A Promise that resolves to the hashed nonce
 */
export async function hashNonce(nonce: string): Promise<string> {
  if (typeof window === "undefined") {
    // Server-side fallback
    return nonce
  }

  // Encode the nonce as UTF-8
  const encoder = new TextEncoder()
  const data = encoder.encode(nonce)

  // Hash the nonce using SHA-256
  const hashBuffer = await window.crypto.subtle.digest("SHA-256", data)

  // Convert the hash to a hex string
  const hashArray = Array.from(new Uint8Array(hashBuffer))
  const hashedNonce = hashArray.map((b) => b.toString(16).padStart(2, "0")).join("")

  return hashedNonce
}
