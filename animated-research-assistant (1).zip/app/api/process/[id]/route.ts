import { NextResponse } from "next/server"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = params.id

    // In a real implementation, you would:
    // 1. Check the status of the processing job in your database
    // 2. Return the actual progress and status

    // For now, we'll simulate a random progress
    const progress = Math.min(100, Math.floor(Math.random() * 100))
    const isComplete = progress === 100

    return NextResponse.json({
      id,
      progress,
      isComplete,
      stage: progress < 20 ? 1 : progress < 40 ? 2 : progress < 60 ? 3 : progress < 80 ? 4 : progress < 95 ? 5 : 6,
    })
  } catch (error) {
    console.error("Process status error:", error)
    return NextResponse.json({ error: "Failed to get process status" }, { status: 500 })
  }
}
