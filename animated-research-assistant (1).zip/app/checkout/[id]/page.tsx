"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { StarField } from "@/components/star-field"
import { ArrowLeft, CreditCard, Download, CheckCircle2 } from "lucide-react"
import Link from "next/link"

export default function CheckoutPage({ params }: { params: { id: string } }) {
  const [isProcessing, setIsProcessing] = useState(false)
  const [isComplete, setIsComplete] = useState(false)
  const [cardNumber, setCardNumber] = useState("")
  const [cardName, setCardName] = useState("")
  const [expiry, setExpiry] = useState("")
  const [cvc, setCvc] = useState("")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsProcessing(true)

    // Simulate payment processing
    setTimeout(() => {
      setIsProcessing(false)
      setIsComplete(true)
    }, 2000)
  }

  const formatCardNumber = (value: string) => {
    // Remove all non-digits
    const digits = value.replace(/\D/g, "")

    // Add space after every 4 digits
    const formatted = digits.replace(/(\d{4})(?=\d)/g, "$1 ")

    // Limit to 19 characters (16 digits + 3 spaces)
    return formatted.slice(0, 19)
  }

  const formatExpiry = (value: string) => {
    // Remove all non-digits
    const digits = value.replace(/\D/g, "")

    // Format as MM/YY
    if (digits.length > 2) {
      return `${digits.slice(0, 2)}/${digits.slice(2, 4)}`
    }

    return digits
  }

  return (
    <main className="min-h-screen bg-black text-white overflow-hidden">
      {/* Background with stars */}
      <div className="fixed inset-0 z-0">
        <StarField />
        <div className="absolute inset-x-0 bottom-0 h-64 bg-gradient-to-t from-black to-transparent" />
      </div>

      <div className="relative z-10 container max-w-4xl mx-auto px-4 py-16">
        {!isComplete && (
          <div className="mb-6">
            <Button variant="ghost" className="text-gray-400 hover:text-white" asChild>
              <Link href={`/preview/${params.id}`}>
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Preview
              </Link>
            </Button>
          </div>
        )}

        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold mb-2">
            {isComplete ? "Thank You for Your Purchase!" : "Complete Your Purchase"}
          </h1>
          <p className="text-gray-400">
            {isComplete
              ? "Your PowerPoint presentation is ready to download"
              : "Your presentation is just one step away"}
          </p>
        </div>

        {!isComplete ? (
          <div className="grid md:grid-cols-5 gap-8">
            <div className="md:col-span-3">
              <div className="bg-gray-900/70 border border-gray-800 rounded-lg p-6">
                <h2 className="text-xl font-bold mb-4 flex items-center">
                  <CreditCard className="mr-2 h-5 w-5" />
                  Payment Details
                </h2>

                <form onSubmit={handleSubmit}>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="cardName">Name on Card</Label>
                      <Input
                        id="cardName"
                        value={cardName}
                        onChange={(e) => setCardName(e.target.value)}
                        placeholder="John Doe"
                        required
                        className="bg-gray-800 border-gray-700"
                      />
                    </div>

                    <div>
                      <Label htmlFor="cardNumber">Card Number</Label>
                      <Input
                        id="cardNumber"
                        value={cardNumber}
                        onChange={(e) => setCardNumber(formatCardNumber(e.target.value))}
                        placeholder="1234 5678 9012 3456"
                        required
                        maxLength={19}
                        className="bg-gray-800 border-gray-700"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="expiry">Expiry Date</Label>
                        <Input
                          id="expiry"
                          value={expiry}
                          onChange={(e) => setExpiry(formatExpiry(e.target.value))}
                          placeholder="MM/YY"
                          required
                          maxLength={5}
                          className="bg-gray-800 border-gray-700"
                        />
                      </div>
                      <div>
                        <Label htmlFor="cvc">CVC</Label>
                        <Input
                          id="cvc"
                          value={cvc}
                          onChange={(e) => setCvc(e.target.value.replace(/\D/g, "").slice(0, 3))}
                          placeholder="123"
                          required
                          maxLength={3}
                          className="bg-gray-800 border-gray-700"
                        />
                      </div>
                    </div>

                    <Button
                      type="submit"
                      className="w-full bg-purple-600 hover:bg-purple-700 mt-4"
                      disabled={isProcessing}
                    >
                      {isProcessing ? (
                        <span className="flex items-center justify-center">
                          <svg
                            className="animate-spin -ml-1 mr-3 h-5 w-5 text-white"
                            xmlns="http://www.w3.org/2000/svg"
                            fill="none"
                            viewBox="0 0 24 24"
                          >
                            <circle
                              className="opacity-25"
                              cx="12"
                              cy="12"
                              r="10"
                              stroke="currentColor"
                              strokeWidth="4"
                            ></circle>
                            <path
                              className="opacity-75"
                              fill="currentColor"
                              d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                            ></path>
                          </svg>
                          Processing...
                        </span>
                      ) : (
                        "Pay $2.00"
                      )}
                    </Button>
                  </div>
                </form>
              </div>
            </div>

            <div className="md:col-span-2">
              <div className="bg-gray-900/70 border border-gray-800 rounded-lg p-6">
                <h2 className="text-xl font-bold mb-4">Order Summary</h2>

                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-gray-400">PDF to PowerPoint Conversion</span>
                    <span>$2.00</span>
                  </div>

                  <div className="border-t border-gray-800 pt-4 flex justify-between font-bold">
                    <span>Total</span>
                    <span>$2.00</span>
                  </div>
                </div>

                <div className="mt-6 text-sm text-gray-400">
                  <p>Your presentation will be available for immediate download after payment.</p>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-gray-900/70 border border-gray-800 rounded-lg p-8 text-center max-w-2xl mx-auto">
            <CheckCircle2 className="h-16 w-16 text-green-500 mx-auto mb-6" />
            <h2 className="text-2xl font-bold mb-4">Payment Successful!</h2>
            <p className="text-gray-400 mb-8">Your PowerPoint presentation is ready to download.</p>

            <Button size="lg" className="bg-purple-600 hover:bg-purple-700">
              <Download className="mr-2 h-5 w-5" />
              Download Presentation
            </Button>

            <div className="mt-8 text-sm text-gray-400">
              <p>A receipt has been sent to your email address.</p>
              <p className="mt-2">
                Having issues?{" "}
                <Link href="/contact" className="text-purple-400 hover:underline">
                  Contact our support team
                </Link>
              </p>
            </div>
          </div>
        )}
      </div>
    </main>
  )
}
