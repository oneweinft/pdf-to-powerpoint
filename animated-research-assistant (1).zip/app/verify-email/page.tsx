"use client"

import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { GradientBackground } from "@/components/gradient-background"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Mail } from "lucide-react"

export default function VerifyEmail() {
  return (
    <main className="min-h-screen bg-black/[0.96] antialiased bg-grid-white/[0.02] relative">
      {/* Background */}
      <div className="h-full w-full absolute inset-0 z-0">
        <GradientBackground />
      </div>

      <div className="relative z-10 flex items-center justify-center min-h-screen p-4">
        <Card className="w-full max-w-md bg-gray-900/70 border border-purple-500/30">
          <CardHeader className="space-y-1">
            <div className="mx-auto bg-purple-600/20 p-3 rounded-full">
              <Mail className="h-10 w-10 text-purple-400" />
            </div>
            <CardTitle className="text-2xl font-bold text-white text-center mt-4">Check your email</CardTitle>
            <CardDescription className="text-gray-400 text-center">
              We've sent you a verification link to your email address
            </CardDescription>
          </CardHeader>
          <CardContent className="text-center text-gray-300 space-y-4">
            <p>
              Please click the link in the email we just sent you to verify your account. If you don't see it, check
              your spam folder.
            </p>
            <p className="text-sm text-gray-400">
              The link will expire in 24 hours. After verifying your email, you'll be able to sign in to your account.
            </p>
          </CardContent>
          <CardFooter className="flex flex-col space-y-4">
            <Button asChild variant="outline" className="w-full border-gray-700 text-white hover:bg-gray-800">
              <Link href="/signin">Return to sign in</Link>
            </Button>
          </CardFooter>
        </Card>
      </div>
    </main>
  )
}
