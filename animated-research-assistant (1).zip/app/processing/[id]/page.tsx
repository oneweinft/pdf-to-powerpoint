"use client"

import { useEffect, useState } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import { StarField } from "@/components/star-field"
import { CheckCircle2, Download, Sparkles, FileText, ImageIcon } from "lucide-react"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { generateText } from "ai"
import { deepseek } from "@ai-sdk/deepseek"

export default function ProcessingPage({ params }: { params: { id: string } }) {
  const [progress, setProgress] = useState(0)
  const [stage, setStage] = useState(1)
  const [isComplete, setIsComplete] = useState(false)
  const [previewUrl, setPreviewUrl] = useState<string | null>(null)
  const [aiInsights, setAiInsights] = useState<string | null>(null)
  const [isLoadingInsights, setIsLoadingInsights] = useState(false)
  const router = useRouter()
  const searchParams = useSearchParams()

  const slideCount = Number.parseInt(searchParams.get("slides") || "5", 10)
  const mediaCount = Number.parseInt(searchParams.get("media") || "0", 10)

  // Stages of processing
  const stages = [
    "Analyzing PDF content",
    "Extracting text and images",
    "Identifying structure and layout",
    "Creating slides and formatting",
    "Adding animations and transitions",
    "Finalizing presentation",
  ]

  useEffect(() => {
    // Simulate processing progress
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setIsComplete(true)
          return 100
        }

        // Update stage based on progress
        if (prev >= 83) setStage(6)
        else if (prev >= 66) setStage(5)
        else if (prev >= 50) setStage(4)
        else if (prev >= 33) setStage(3)
        else if (prev >= 16) setStage(2)

        return prev + 1
      })
    }, 120)

    // Simulate generating a preview URL when complete
    setTimeout(() => {
      setPreviewUrl("/preview-presentation.png")
    }, 7500)

    return () => clearInterval(interval)
  }, [])

  // Generate AI insights when processing is complete
  useEffect(() => {
    if (isComplete && !aiInsights && !isLoadingInsights) {
      generateAIInsights()
    }
  }, [isComplete, aiInsights, isLoadingInsights])

  const generateAIInsights = async () => {
    setIsLoadingInsights(true)
    try {
      const { text } = await generateText({
        model: deepseek("deepseek-chat"),
        prompt: `Generate 3-4 insights about a PowerPoint presentation that was created from a PDF. The presentation has ${slideCount} slides and includes ${mediaCount} images.`,
        system:
          "You are an AI assistant that provides helpful insights about presentations. Be concise and professional.",
      })

      setAiInsights(text)
    } catch (error) {
      console.error("Error generating AI insights:", error)
      setAiInsights("Unable to generate AI insights at this time.")
    } finally {
      setIsLoadingInsights(false)
    }
  }

  return (
    <main className="min-h-screen bg-black text-white overflow-hidden">
      {/* Background with stars */}
      <div className="fixed inset-0 z-0">
        <StarField />
        <div className="absolute inset-x-0 bottom-0 h-64 bg-gradient-to-t from-black to-transparent" />
      </div>

      <div className="relative z-10 container max-w-4xl mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">Processing Your Presentation</h1>
          <p className="text-gray-400">We're transforming your PDF into a stunning PowerPoint presentation</p>

          <div className="flex flex-wrap justify-center gap-2 mt-4">
            <Badge variant="outline" className="bg-gray-800">
              <FileText className="h-3 w-3 mr-1" /> 1 PDF
            </Badge>
            <Badge variant="outline" className="bg-gray-800">
              {slideCount} {slideCount === 1 ? "slide" : "slides"}
            </Badge>
            {mediaCount > 0 && (
              <Badge variant="outline" className="bg-gray-800">
                <ImageIcon className="h-3 w-3 mr-1" /> {mediaCount} {mediaCount === 1 ? "image" : "images"}
              </Badge>
            )}
            <Badge variant="outline" className="bg-purple-900/50 border-purple-500/30">
              <Sparkles className="h-3 w-3 mr-1 text-purple-400" /> DeepSeek AI
            </Badge>
          </div>
        </div>

        <div className="bg-gray-900/70 border border-gray-800 rounded-lg p-6 mb-8">
          <div className="mb-6">
            <div className="flex justify-between mb-2">
              <span className="text-sm text-gray-400">Progress</span>
              <span className="text-sm font-medium">{progress}%</span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>

          <div className="space-y-4">
            {stages.map((stageText, index) => (
              <div key={index} className="flex items-center">
                <div
                  className={`w-6 h-6 rounded-full flex items-center justify-center mr-3 ${
                    index + 1 < stage
                      ? "bg-green-500"
                      : index + 1 === stage
                        ? "bg-purple-600 animate-pulse"
                        : "bg-gray-700"
                  }`}
                >
                  {index + 1 < stage ? (
                    <CheckCircle2 className="h-4 w-4 text-white" />
                  ) : (
                    <span className="text-xs text-white">{index + 1}</span>
                  )}
                </div>
                <span
                  className={`${
                    index + 1 < stage ? "text-green-400" : index + 1 === stage ? "text-white" : "text-gray-500"
                  }`}
                >
                  {stageText}
                </span>
              </div>
            ))}
          </div>
        </div>

        {isComplete && (
          <div className="bg-gray-900/70 border border-gray-800 rounded-lg p-6 animate-fadeIn">
            <div className="text-center mb-6">
              <CheckCircle2 className="h-12 w-12 text-green-500 mx-auto mb-4" />
              <h2 className="text-2xl font-bold mb-2">Processing Complete!</h2>
              <p className="text-gray-400">Your PowerPoint presentation is ready for preview</p>
            </div>

            {previewUrl && (
              <div className="mb-6">
                <div className="relative aspect-video bg-gray-800 rounded-md overflow-hidden">
                  <img
                    src={previewUrl || "/placeholder.svg"}
                    alt="Presentation Preview"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Button
                      variant="outline"
                      className="bg-black/50 border-white text-white hover:bg-black/70"
                      onClick={() => router.push(`/preview/${params.id}?slides=${slideCount}&media=${mediaCount}`)}
                    >
                      View Preview
                    </Button>
                  </div>
                </div>
              </div>
            )}

            {aiInsights && (
              <div className="mb-6 bg-purple-900/20 border border-purple-500/30 rounded-lg p-4">
                <div className="flex items-center mb-2">
                  <Sparkles className="h-5 w-5 text-purple-400 mr-2" />
                  <h3 className="font-medium">AI Insights</h3>
                </div>
                <p className="text-gray-300 text-sm">{aiInsights}</p>
              </div>
            )}

            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button variant="outline" className="border-gray-600 text-gray-300 hover:bg-gray-800" asChild>
                <Link href="/">Start Over</Link>
              </Button>
              <Button className="bg-purple-600 hover:bg-purple-700" asChild>
                <Link href={`/checkout/${params.id}?slides=${slideCount}&media=${mediaCount}`}>
                  <Download className="mr-2 h-4 w-4" />
                  Purchase & Download ($2.00)
                </Link>
              </Button>
            </div>
          </div>
        )}
      </div>
    </main>
  )
}
