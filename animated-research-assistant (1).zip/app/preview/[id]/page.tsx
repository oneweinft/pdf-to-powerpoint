"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { StarField } from "@/components/star-field"
import { ChevronLeft, ChevronRight, Download, ArrowLeft, Sparkles, FileText, ImageIcon } from "lucide-react"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Mock presentation slides
const mockSlides = [
  {
    id: 1,
    title: "Introduction",
    imageUrl: "/preview-slides/slide1.png",
    notes: "Opening slide with main topic introduction",
  },
  {
    id: 2,
    title: "Key Points",
    imageUrl: "/preview-slides/slide2.png",
    notes: "Summary of the main arguments and points",
  },
  {
    id: 3,
    title: "Data Analysis",
    imageUrl: "/preview-slides/slide3.png",
    notes: "Graph showing quarterly results and trends",
  },
  {
    id: 4,
    title: "Comparison",
    imageUrl: "/preview-slides/slide4.png",
    notes: "Side-by-side comparison of different approaches",
  },
  {
    id: 5,
    title: "Conclusion",
    imageUrl: "/preview-slides/slide5.png",
    notes: "Summary and next steps",
  },
]

export default function PreviewPage({ params }: { params: { id: string } }) {
  const [currentSlide, setCurrentSlide] = useState(0)
  const [aiEnhancements, setAiEnhancements] = useState<string[]>([
    "Improved text clarity and readability",
    "Enhanced color scheme for better visual appeal",
    "Optimized layout for better content flow",
    "Added professional animations between slides",
  ])
  const searchParams = useSearchParams()

  const slideCount = Number.parseInt(searchParams.get("slides") || "5", 10)
  const mediaCount = Number.parseInt(searchParams.get("media") || "0", 10)

  // Dynamically adjust mockSlides based on slideCount
  useEffect(() => {
    // This is just for demo purposes - in a real app, you'd fetch the actual slides
    if (mockSlides.length !== slideCount) {
      // Keep the code simple for the demo
    }
  }, [slideCount])

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % mockSlides.length)
  }

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + mockSlides.length) % mockSlides.length)
  }

  return (
    <main className="min-h-screen bg-black text-white overflow-hidden">
      {/* Background with stars */}
      <div className="fixed inset-0 z-0">
        <StarField />
        <div className="absolute inset-x-0 bottom-0 h-64 bg-gradient-to-t from-black to-transparent" />
      </div>

      <div className="relative z-10 container mx-auto px-4 py-8">
        <div className="mb-6">
          <Button variant="ghost" className="text-gray-400 hover:text-white" asChild>
            <Link href={`/processing/${params.id}?slides=${slideCount}&media=${mediaCount}`}>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Processing
            </Link>
          </Button>
        </div>

        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold mb-2">Presentation Preview</h1>
          <p className="text-gray-400">
            Slide {currentSlide + 1} of {mockSlides.length}
          </p>

          <div className="flex flex-wrap justify-center gap-2 mt-4">
            <Badge variant="outline" className="bg-gray-800">
              <FileText className="h-3 w-3 mr-1" /> 1 PDF
            </Badge>
            <Badge variant="outline" className="bg-gray-800">
              {slideCount} {slideCount === 1 ? "slide" : "slides"}
            </Badge>
            {mediaCount > 0 && (
              <Badge variant="outline" className="bg-gray-800">
                <ImageIcon className="h-3 w-3 mr-1" /> {mediaCount} {mediaCount === 1 ? "image" : "images"}
              </Badge>
            )}
            <Badge variant="outline" className="bg-purple-900/50 border-purple-500/30">
              <Sparkles className="h-3 w-3 mr-1 text-purple-400" /> DeepSeek AI
            </Badge>
          </div>
        </div>

        <div className="max-w-5xl mx-auto">
          {/* Slide viewer */}
          <div className="relative bg-gray-900/70 border border-gray-800 rounded-lg p-4 mb-8">
            <div className="aspect-[16/9] bg-gray-800 rounded overflow-hidden">
              <img
                src={
                  mockSlides[currentSlide].imageUrl || "/placeholder.svg?height=720&width=1280&query=presentation slide"
                }
                alt={`Slide ${currentSlide + 1}`}
                className="w-full h-full object-cover"
              />
            </div>

            {/* Navigation arrows */}
            <button
              onClick={prevSlide}
              className="absolute left-8 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/50 flex items-center justify-center hover:bg-black/70 transition-colors"
              aria-label="Previous slide"
            >
              <ChevronLeft className="h-6 w-6" />
            </button>
            <button
              onClick={nextSlide}
              className="absolute right-8 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/50 flex items-center justify-center hover:bg-black/70 transition-colors"
              aria-label="Next slide"
            >
              <ChevronRight className="h-6 w-6" />
            </button>
          </div>

          {/* Slide info and AI enhancements */}
          <div className="grid md:grid-cols-2 gap-6 mb-8">
            <div className="bg-gray-900/70 border border-gray-800 rounded-lg p-6">
              <Tabs defaultValue="info">
                <TabsList className="mb-4">
                  <TabsTrigger value="info">Slide Info</TabsTrigger>
                  <TabsTrigger value="ai">AI Enhancements</TabsTrigger>
                </TabsList>

                <TabsContent value="info">
                  <h2 className="text-xl font-bold mb-2">{mockSlides[currentSlide].title}</h2>
                  <p className="text-gray-400 mb-4">{mockSlides[currentSlide].notes}</p>

                  <div className="flex flex-wrap gap-2">
                    <span className="px-3 py-1 bg-gray-800 rounded-full text-xs text-gray-300">Animations: 2</span>
                    <span className="px-3 py-1 bg-gray-800 rounded-full text-xs text-gray-300">Images: 1</span>
                    <span className="px-3 py-1 bg-gray-800 rounded-full text-xs text-gray-300">Charts: 1</span>
                  </div>
                </TabsContent>

                <TabsContent value="ai">
                  <div className="flex items-center mb-3">
                    <Sparkles className="h-5 w-5 text-purple-400 mr-2" />
                    <h2 className="text-lg font-bold">AI Enhancements</h2>
                  </div>
                  <ul className="space-y-2">
                    {aiEnhancements.map((enhancement, index) => (
                      <li key={index} className="flex items-start">
                        <div className="h-5 w-5 rounded-full bg-purple-900/50 flex items-center justify-center mr-2 mt-0.5">
                          <Sparkles className="h-3 w-3 text-purple-400" />
                        </div>
                        <span className="text-gray-300 text-sm">{enhancement}</span>
                      </li>
                    ))}
                  </ul>
                </TabsContent>
              </Tabs>
            </div>

            <div className="bg-gray-900/70 border border-gray-800 rounded-lg p-6">
              <h2 className="text-xl font-bold mb-4">Media Used</h2>
              <div className="grid grid-cols-3 gap-3">
                {[...Array(Math.min(mediaCount, 6))].map((_, index) => (
                  <div key={index} className="aspect-square bg-gray-800 rounded-md overflow-hidden">
                    <img
                      src={`/abstract-geometric-shapes.png?height=100&width=100&query=image ${index + 1}`}
                      alt={`Media ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </div>
                ))}
                {mediaCount === 0 && (
                  <div className="col-span-3 text-center py-8 text-gray-400">
                    <ImageIcon className="h-10 w-10 mx-auto mb-2 opacity-30" />
                    <p>No additional media files</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Thumbnails */}
          <div className="grid grid-cols-5 gap-2 mb-8">
            {mockSlides.map((slide, index) => (
              <button
                key={slide.id}
                onClick={() => setCurrentSlide(index)}
                className={`aspect-video rounded overflow-hidden border-2 ${
                  currentSlide === index ? "border-purple-500" : "border-transparent hover:border-gray-600"
                }`}
              >
                <img
                  src={slide.imageUrl || `/placeholder.svg?height=180&width=320&query=slide ${index + 1}`}
                  alt={`Thumbnail ${index + 1}`}
                  className="w-full h-full object-cover"
                />
              </button>
            ))}
          </div>

          {/* Action buttons */}
          <div className="flex justify-center">
            <Button className="bg-purple-600 hover:bg-purple-700" asChild>
              <Link href={`/checkout/${params.id}?slides=${slideCount}&media=${mediaCount}`}>
                <Download className="mr-2 h-4 w-4" />
                Purchase & Download ($2.00)
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </main>
  )
}
