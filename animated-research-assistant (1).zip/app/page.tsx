import { Button } from "@/components/ui/button"
import { StarField } from "@/components/star-field"
import { FileUploader } from "@/components/file-uploader"
import { HowItWorks } from "@/components/how-it-works"
import { Pricing } from "@/components/pricing"
import { Features } from "@/components/features"
import { Testimonials } from "@/components/testimonials"
import { FAQ } from "@/components/faq"
import { ContactForm } from "@/components/contact-form"
import { Navbar } from "@/components/navbar"
import { AIChatbot } from "@/components/ai-chatbot"
import { AIIntegration } from "@/components/ai-integration"
import Link from "next/link"

export default function Home() {
  return (
    <main className="min-h-screen bg-black text-white overflow-hidden">
      {/* Background with stars and mountain silhouette */}
      <div className="fixed inset-0 z-0">
        <StarField />
        <div className="absolute inset-x-0 bottom-0 h-64 bg-gradient-to-t from-black to-transparent" />
        <div
          className="absolute inset-x-0 bottom-0 h-48 bg-[url('/images/mountains.png')] bg-bottom bg-cover"
          style={{ maskImage: "linear-gradient(to top, black, transparent)" }}
        />
      </div>

      <Navbar />

      {/* AI Chatbot */}
      <AIChatbot />

      {/* Hero Section */}
      <section className="relative z-10 flex flex-col items-center justify-center min-h-screen px-4 text-center pt-16">
        <h1 className="text-5xl md:text-7xl font-bold tracking-tighter mb-6">DEATH WORKS AI</h1>
        <p className="text-2xl md:text-3xl font-light mb-8 max-w-2xl text-gray-300">
          Transform your PDFs into stunning PowerPoint presentations with AI
        </p>
        <div className="w-full max-w-4xl mx-auto grid md:grid-cols-3 gap-6">
          <div className="md:col-span-2">
            <FileUploader />
          </div>
          <div className="md:col-span-1">
            <AIIntegration />
          </div>
        </div>
        <div className="mt-8">
          <Button asChild size="lg" variant="outline" className="border-purple-500 text-purple-400 hover:bg-purple-950">
            <Link href="#how-it-works">Learn More</Link>
          </Button>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="relative z-10 py-20 px-4">
        <HowItWorks />
      </section>

      {/* Features Section */}
      <section id="features" className="relative z-10 py-20 px-4 bg-gray-900/50">
        <Features />
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="relative z-10 py-20 px-4">
        <Pricing />
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="relative z-10 py-20 px-4 bg-gray-900/50">
        <Testimonials />
      </section>

      {/* FAQ Section */}
      <section id="faq" className="relative z-10 py-20 px-4">
        <FAQ />
      </section>

      {/* Contact Section */}
      <section id="contact" className="relative z-10 py-20 px-4 bg-gray-900/50">
        <ContactForm />
      </section>

      {/* Footer */}
      <footer className="relative z-10 py-8 px-4 text-center text-gray-400 border-t border-gray-800">
        <div className="max-w-7xl mx-auto">
          <p>© {new Date().getFullYear()} Death Works AI. All rights reserved.</p>
          <div className="mt-4 flex justify-center space-x-6">
            <Link href="/terms" className="hover:text-white">
              Terms
            </Link>
            <Link href="/privacy" className="hover:text-white">
              Privacy
            </Link>
            <Link href="/contact" className="hover:text-white">
              Contact
            </Link>
          </div>
        </div>
      </footer>
    </main>
  )
}
