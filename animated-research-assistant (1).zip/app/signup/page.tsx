"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { SparklesCore } from "@/components/sparkles"
import { GradientBackground } from "@/components/gradient-background"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { z } from "zod"
import { toast } from "@/components/ui/use-toast"
import { Loader2, Check, X } from "lucide-react"
import { Checkbox } from "@/components/ui/checkbox"
import { createClient } from "@/utils/supabase/client"
import { GoogleAuth } from "@/components/google-auth"

// Email validation schema
const emailSchema = z.string().email("Please enter a valid email address")

// Password validation schema
const passwordSchema = z
  .string()
  .min(8, "Password must be at least 8 characters")
  .regex(/[A-Z]/, "Password must contain at least one uppercase letter")
  .regex(/[a-z]/, "Password must contain at least one lowercase letter")
  .regex(/[0-9]/, "Password must contain at least one number")
  .regex(/[^A-Za-z0-9]/, "Password must contain at least one special character")

export default function SignUp() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [firstName, setFirstName] = useState("")
  const [lastName, setLastName] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [step, setStep] = useState(1)
  const [emailError, setEmailError] = useState("")
  const [passwordErrors, setPasswordErrors] = useState<string[]>([])
  const [confirmError, setConfirmError] = useState("")
  const [acceptTerms, setAcceptTerms] = useState(false)
  const [acceptMarketing, setAcceptMarketing] = useState(false)
  const [useSparkles, setUseSparkles] = useState(true)
  const router = useRouter()
  const supabase = createClient()

  // Validate email
  const validateEmail = (email: string) => {
    try {
      emailSchema.parse(email)
      setEmailError("")
      return true
    } catch (error) {
      if (error instanceof z.ZodError) {
        setEmailError(error.errors[0].message)
      }
      return false
    }
  }

  // Validate password
  const validatePassword = (password: string) => {
    try {
      passwordSchema.parse(password)
      setPasswordErrors([])
      return true
    } catch (error) {
      if (error instanceof z.ZodError) {
        setPasswordErrors(error.errors.map((e) => e.message))
      }
      return false
    }
  }

  // Validate confirm password
  const validateConfirmPassword = (password: string, confirmPassword: string) => {
    if (password !== confirmPassword) {
      setConfirmError("Passwords do not match")
      return false
    }
    setConfirmError("")
    return true
  }

  const handleNextStep = () => {
    if (step === 1) {
      const isEmailValid = validateEmail(email)
      if (!isEmailValid) return

      // Check if email already exists
      supabase.auth
        .signInWithOtp({
          email,
          options: {
            shouldCreateUser: false,
          },
        })
        .then(({ error }) => {
          // If there's no error, the email exists
          if (!error) {
            setEmailError("This email is already registered")
            return
          }

          // If the error is not about the email not existing, show it
          if (error.message !== "Email not found") {
            setEmailError(error.message)
            return
          }

          // Email is valid and doesn't exist
          setStep(2)
        })
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    // Validate all fields
    const isEmailValid = validateEmail(email)
    const isPasswordValid = validatePassword(password)
    const isConfirmValid = validateConfirmPassword(password, confirmPassword)

    if (!isEmailValid || !isPasswordValid || !isConfirmValid || !acceptTerms) {
      return
    }

    setIsLoading(true)

    try {
      // Register user with Supabase
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            first_name: firstName,
            last_name: lastName,
            accept_marketing: acceptMarketing,
          },
          emailRedirectTo: `${window.location.origin}/auth/callback`,
        },
      })

      if (error) throw error

      // Create user profile in the database
      if (data.user) {
        const { error: profileError } = await supabase.from("profiles").insert({
          id: data.user.id,
          email: email.toLowerCase(),
          first_name: firstName,
          last_name: lastName,
          remaining_searches: 5,
          email_verified: false,
          accept_marketing: acceptMarketing,
        })

        if (profileError) throw profileError
      }

      toast({
        title: "Account created!",
        description: "We've sent a verification email to your inbox.",
      })

      // Redirect to email verification page
      router.push("/verify-email")
    } catch (error: any) {
      console.error("Sign-up error:", error)
      toast({
        title: "Account creation failed",
        description: error.message || "An unexpected error occurred. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Add this function to your signup page to handle development environment
  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault()

    // Validate fields...

    setIsLoading(true)

    try {
      // Register user with Supabase
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            first_name: firstName,
            last_name: lastName,
            accept_marketing: acceptMarketing,
          },
          emailRedirectTo: `${window.location.origin}/auth/callback`,
        },
      })

      if (error) throw error

      // Create user profile in the database
      if (data.user) {
        const { error: profileError } = await supabase.from("profiles").insert({
          id: data.user.id,
          email: email.toLowerCase(),
          first_name: firstName,
          last_name: lastName,
          remaining_searches: 5,
          email_verified: false,
          accept_marketing: acceptMarketing,
        })

        if (profileError) throw profileError

        // For development only - automatically confirm email
        if (process.env.NODE_ENV === "development") {
          // This is just for development testing - DO NOT use in production
          toast({
            title: "Development mode",
            description: "Email verification is simulated in development",
          })

          // Redirect to dashboard or verification page as needed
          router.push("/verify-email")
        } else {
          toast({
            title: "Account created!",
            description: "We've sent a verification email to your inbox.",
          })

          // Redirect to email verification page
          router.push("/verify-email")
        }
      }
    } catch (error: any) {
      console.error("Sign-up error:", error)
      toast({
        title: "Account creation failed",
        description: error.message || "An unexpected error occurred. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // If there's an error with SparklesCore, switch to the fallback background
  const handleSparklesError = () => {
    setUseSparkles(false)
  }

  return (
    <main className="min-h-screen bg-black/[0.96] antialiased bg-grid-white/[0.02] relative">
      {/* Ambient background with moving particles */}
      <div className="h-full w-full absolute inset-0 z-0">
        {useSparkles ? (
          <div onError={handleSparklesError}>
            <SparklesCore
              id="tsparticlesfullpage"
              background="transparent"
              minSize={0.6}
              maxSize={1.4}
              particleDensity={100}
              className="w-full h-full"
              particleColor="#FFFFFF"
            />
          </div>
        ) : (
          <GradientBackground />
        )}
      </div>

      <div className="relative z-10 flex items-center justify-center min-h-screen p-4">
        <Card className="w-full max-w-md bg-gray-900/70 border border-purple-500/30">
          <CardHeader className="space-y-1">
            <div className="flex items-center justify-center mb-2">
              <div className="flex items-center justify-center w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-600 text-white font-bold text-xl">
                ez
              </div>
              <span className="text-white font-medium text-xl">yname</span>
            </div>
            <CardTitle className="text-2xl font-bold text-white text-center">Create your account</CardTitle>
            <CardDescription className="text-gray-400 text-center">
              {step === 1 ? "Enter your email to get started" : "Set up your account details"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {step === 1 ? (
              <div className="space-y-4">
                <div className="space-y-2">
                  <label htmlFor="email" className="text-sm font-medium text-gray-300">
                    Email
                  </label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="your@email.com"
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value)
                      if (e.target.value) validateEmail(e.target.value)
                    }}
                    className={`bg-gray-800 border-gray-700 ${emailError ? "border-red-500" : ""}`}
                  />
                  {emailError && <p className="text-sm text-red-500">{emailError}</p>}
                </div>
                <Button type="button" className="w-full bg-purple-600 hover:bg-purple-700" onClick={handleNextStep}>
                  Continue
                </Button>

                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <span className="w-full border-t border-gray-700" />
                  </div>
                  <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-gray-900 px-2 text-gray-500">Or</span>
                  </div>
                </div>

                <GoogleAuth redirectTo="/dashboard" useOneTap={true} />
              </div>
            ) : (
              <form onSubmit={handleSubmit}>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label htmlFor="firstName" className="text-sm font-medium text-gray-300">
                        First Name
                      </label>
                      <Input
                        id="firstName"
                        placeholder="John"
                        value={firstName}
                        onChange={(e) => setFirstName(e.target.value)}
                        className="bg-gray-800 border-gray-700"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="lastName" className="text-sm font-medium text-gray-300">
                        Last Name
                      </label>
                      <Input
                        id="lastName"
                        placeholder="Doe"
                        value={lastName}
                        onChange={(e) => setLastName(e.target.value)}
                        className="bg-gray-800 border-gray-700"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label htmlFor="password" className="text-sm font-medium text-gray-300">
                      Password
                    </label>
                    <Input
                      id="password"
                      type="password"
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => {
                        setPassword(e.target.value)
                        if (e.target.value) validatePassword(e.target.value)
                        if (confirmPassword) validateConfirmPassword(e.target.value, confirmPassword)
                      }}
                      className={`bg-gray-800 border-gray-700 ${passwordErrors.length > 0 ? "border-red-500" : ""}`}
                      required
                    />

                    {/* Password strength indicators */}
                    <div className="space-y-1 mt-2">
                      <PasswordRequirement text="At least 8 characters" satisfied={password.length >= 8} />
                      <PasswordRequirement text="Contains uppercase letter" satisfied={/[A-Z]/.test(password)} />
                      <PasswordRequirement text="Contains lowercase letter" satisfied={/[a-z]/.test(password)} />
                      <PasswordRequirement text="Contains number" satisfied={/[0-9]/.test(password)} />
                      <PasswordRequirement
                        text="Contains special character"
                        satisfied={/[^A-Za-z0-9]/.test(password)}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label htmlFor="confirmPassword" className="text-sm font-medium text-gray-300">
                      Confirm Password
                    </label>
                    <Input
                      id="confirmPassword"
                      type="password"
                      placeholder="••••••••"
                      value={confirmPassword}
                      onChange={(e) => {
                        setConfirmPassword(e.target.value)
                        if (e.target.value) validateConfirmPassword(password, e.target.value)
                      }}
                      className={`bg-gray-800 border-gray-700 ${confirmError ? "border-red-500" : ""}`}
                      required
                    />
                    {confirmError && <p className="text-sm text-red-500">{confirmError}</p>}
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="terms"
                        checked={acceptTerms}
                        onCheckedChange={(checked) => setAcceptTerms(checked as boolean)}
                        required
                      />
                      <label htmlFor="terms" className="text-sm text-gray-300">
                        I agree to the{" "}
                        <Link href="/terms" className="text-purple-400 hover:underline">
                          Terms of Service
                        </Link>{" "}
                        and{" "}
                        <Link href="/privacy" className="text-purple-400 hover:underline">
                          Privacy Policy
                        </Link>
                      </label>
                    </div>

                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="marketing"
                        checked={acceptMarketing}
                        onCheckedChange={(checked) => setAcceptMarketing(checked as boolean)}
                      />
                      <label htmlFor="marketing" className="text-sm text-gray-300">
                        I agree to receive marketing emails (optional)
                      </label>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <Button
                      type="button"
                      variant="outline"
                      className="flex-1 border-gray-700 text-white hover:bg-gray-800"
                      onClick={() => setStep(1)}
                    >
                      Back
                    </Button>
                    <Button
                      type="submit"
                      className="flex-1 bg-purple-600 hover:bg-purple-700"
                      disabled={isLoading || !password || !!confirmError || passwordErrors.length > 0}
                    >
                      {isLoading ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Creating...
                        </>
                      ) : (
                        "Create Account"
                      )}
                    </Button>
                  </div>
                </div>
              </form>
            )}
          </CardContent>
          <CardFooter className="flex justify-center">
            <div className="text-sm text-gray-400">
              Already have an account?{" "}
              <Link href="/signin" className="text-purple-400 hover:text-purple-300">
                Sign in
              </Link>
            </div>
          </CardFooter>
        </Card>
      </div>
    </main>
  )
}

function PasswordRequirement({ text, satisfied }: { text: string; satisfied: boolean }) {
  return (
    <div className="flex items-center space-x-2">
      {satisfied ? <Check className="h-4 w-4 text-green-500" /> : <X className="h-4 w-4 text-gray-400" />}
      <span className={`text-xs ${satisfied ? "text-green-500" : "text-gray-400"}`}>{text}</span>
    </div>
  )
}
