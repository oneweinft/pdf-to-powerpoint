"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Upload, FileText, AlertCircle, ImageIcon, Plus, Minus, X } from "lucide-react"
import { useRouter } from "next/navigation"
import { Slider } from "@/components/ui/slider"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"

export function FileUploader() {
  const [file, setFile] = useState<File | null>(null)
  const [mediaFiles, setMediaFiles] = useState<File[]>([])
  const [isDragging, setIsDragging] = useState(false)
  const [isUploading, setIsUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [error, setError] = useState<string | null>(null)
  const [slideCount, setSlideCount] = useState(5)
  const [activeTab, setActiveTab] = useState("pdf")
  const fileInputRef = useRef<HTMLInputElement>(null)
  const mediaInputRef = useRef<HTMLInputElement>(null)
  const router = useRouter()

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }

  const handleDragLeave = () => {
    setIsDragging(false)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      if (activeTab === "pdf") {
        validateAndSetFile(e.dataTransfer.files[0])
      } else if (activeTab === "media") {
        handleMediaFiles(e.dataTransfer.files)
      }
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      validateAndSetFile(e.target.files[0])
    }
  }

  const handleMediaChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      handleMediaFiles(e.target.files)
    }
  }

  const handleMediaFiles = (files: FileList) => {
    setError(null)
    const newMediaFiles = [...mediaFiles]

    Array.from(files).forEach((file) => {
      // Check file type
      if (!file.type.includes("image/jpeg") && !file.type.includes("image/png")) {
        setError("Please upload only JPEG or PNG images")
        return
      }

      // Check file size (2MB = 2 * 1024 * 1024 bytes)
      if (file.size > 2 * 1024 * 1024) {
        setError("Image size must be less than 2MB")
        return
      }

      // Add to media files array
      newMediaFiles.push(file)
    })

    // Limit to 10 media files
    if (newMediaFiles.length > 10) {
      setError("You can upload a maximum of 10 images")
      setMediaFiles(newMediaFiles.slice(0, 10))
    } else {
      setMediaFiles(newMediaFiles)
    }
  }

  const removeMediaFile = (index: number) => {
    const newMediaFiles = [...mediaFiles]
    newMediaFiles.splice(index, 1)
    setMediaFiles(newMediaFiles)
  }

  const validateAndSetFile = (file: File) => {
    setError(null)

    // Check file type
    if (!file.type.includes("pdf")) {
      setError("Please upload a PDF file")
      return
    }

    // Check file size (5MB = 5 * 1024 * 1024 bytes)
    if (file.size > 5 * 1024 * 1024) {
      setError("File size must be less than 5MB")
      return
    }

    setFile(file)
  }

  const handleUpload = async () => {
    if (!file) return

    setIsUploading(true)
    setUploadProgress(0)

    // Simulate upload progress
    const interval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 95) {
          clearInterval(interval)
          return 95
        }
        return prev + 5
      })
    }, 200)

    try {
      // Here you would actually upload the file to your server
      const formData = new FormData()
      formData.append("file", file)
      formData.append("slideCount", slideCount.toString())

      // Add media files
      mediaFiles.forEach((mediaFile, index) => {
        formData.append(`media_${index}`, mediaFile)
      })

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 2000))

      clearInterval(interval)
      setUploadProgress(100)

      // Redirect to processing page with a simulated file ID
      setTimeout(() => {
        router.push(`/processing/${Date.now().toString()}?slides=${slideCount}&media=${mediaFiles.length}`)
      }, 500)
    } catch (error) {
      clearInterval(interval)
      setError("Upload failed. Please try again.")
      setIsUploading(false)
    }
  }

  const triggerFileInput = () => {
    if (activeTab === "pdf") {
      fileInputRef.current?.click()
    } else if (activeTab === "media") {
      mediaInputRef.current?.click()
    }
  }

  return (
    <div className="w-full">
      <Tabs defaultValue="pdf" className="mb-4" onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-2 mb-4">
          <TabsTrigger value="pdf">PDF Document</TabsTrigger>
          <TabsTrigger value="media">Media Files</TabsTrigger>
        </TabsList>

        <TabsContent value="pdf">
          <div
            className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
              isDragging
                ? "border-purple-500 bg-purple-900/20"
                : file
                  ? "border-green-500 bg-green-900/10"
                  : "border-gray-600 hover:border-gray-500 bg-gray-900/50 hover:bg-gray-800/50"
            }`}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={!file ? triggerFileInput : undefined}
            style={{ cursor: !file ? "pointer" : "default" }}
          >
            <input type="file" ref={fileInputRef} onChange={handleFileChange} accept=".pdf" className="hidden" />

            {!file ? (
              <div className="flex flex-col items-center justify-center py-4">
                <Upload className="h-12 w-12 text-gray-400 mb-4" />
                <p className="text-xl font-medium mb-1">Drop your PDF here</p>
                <p className="text-sm text-gray-400 mb-4">or click to browse (max 5MB)</p>
                <Button
                  variant="outline"
                  onClick={(e) => {
                    e.stopPropagation()
                    triggerFileInput()
                  }}
                  className="border-purple-500 text-purple-400 hover:bg-purple-950"
                >
                  Select PDF
                </Button>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-4">
                <FileText className="h-12 w-12 text-green-400 mb-4" />
                <p className="text-xl font-medium mb-1">{file.name}</p>
                <p className="text-sm text-gray-400 mb-4">{(file.size / (1024 * 1024)).toFixed(2)} MB</p>

                {isUploading ? (
                  <div className="w-full max-w-xs">
                    <Progress value={uploadProgress} className="h-2 mb-2" />
                    <p className="text-sm text-gray-400">Uploading... {uploadProgress}%</p>
                  </div>
                ) : (
                  <div className="flex space-x-3">
                    <Button
                      variant="outline"
                      onClick={() => setFile(null)}
                      className="border-gray-600 text-gray-400 hover:bg-gray-800"
                    >
                      Change
                    </Button>
                  </div>
                )}
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="media">
          <div
            className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
              isDragging
                ? "border-purple-500 bg-purple-900/20"
                : mediaFiles.length > 0
                  ? "border-blue-500 bg-blue-900/10"
                  : "border-gray-600 hover:border-gray-500 bg-gray-900/50 hover:bg-gray-800/50"
            }`}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={triggerFileInput}
            style={{ cursor: "pointer" }}
          >
            <input
              type="file"
              ref={mediaInputRef}
              onChange={handleMediaChange}
              accept=".jpg,.jpeg,.png"
              className="hidden"
              multiple
            />

            <div className="flex flex-col items-center justify-center py-4">
              <ImageIcon className="h-12 w-12 text-gray-400 mb-4" />
              <p className="text-xl font-medium mb-1">Add images to your presentation</p>
              <p className="text-sm text-gray-400 mb-4">Drop JPG or PNG files here (max 2MB each)</p>
              <Button
                variant="outline"
                onClick={(e) => {
                  e.stopPropagation()
                  triggerFileInput()
                }}
                className="border-purple-500 text-purple-400 hover:bg-purple-950"
              >
                Select Images
              </Button>
            </div>
          </div>

          {mediaFiles.length > 0 && (
            <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
              {mediaFiles.map((mediaFile, index) => (
                <div key={index} className="relative group">
                  <div className="aspect-square bg-gray-800 rounded-md overflow-hidden">
                    <img
                      src={URL.createObjectURL(mediaFile) || "/placeholder.svg"}
                      alt={`Media ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <button
                    onClick={() => removeMediaFile(index)}
                    className="absolute top-1 right-1 bg-red-600 rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                    aria-label="Remove image"
                  >
                    <X className="h-4 w-4" />
                  </button>
                  <p className="text-xs text-gray-400 truncate mt-1">{mediaFile.name}</p>
                </div>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      <div className="mt-6 bg-gray-900/70 border border-gray-800 rounded-lg p-6">
        <div className="mb-4">
          <div className="flex justify-between items-center mb-2">
            <label htmlFor="slide-count" className="text-sm font-medium">
              Number of Slides: <span className="text-purple-400 font-bold">{slideCount}</span>
            </label>
          </div>
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              size="icon"
              onClick={() => setSlideCount(Math.max(1, slideCount - 1))}
              className="h-8 w-8"
              disabled={slideCount <= 1}
            >
              <Minus className="h-4 w-4" />
            </Button>
            <Slider
              id="slide-count"
              value={[slideCount]}
              min={1}
              max={10}
              step={1}
              onValueChange={(value) => setSlideCount(value[0])}
              className="flex-1"
            />
            <Button
              variant="outline"
              size="icon"
              onClick={() => setSlideCount(Math.min(10, slideCount + 1))}
              className="h-8 w-8"
              disabled={slideCount >= 10}
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="flex flex-wrap gap-2 mb-4">
          <Badge variant="outline" className="bg-gray-800">
            {slideCount} {slideCount === 1 ? "slide" : "slides"}
          </Badge>
          {file && (
            <Badge variant="outline" className="bg-gray-800">
              1 PDF
            </Badge>
          )}
          {mediaFiles.length > 0 && (
            <Badge variant="outline" className="bg-gray-800">
              {mediaFiles.length} {mediaFiles.length === 1 ? "image" : "images"}
            </Badge>
          )}
        </div>

        <Button
          onClick={handleUpload}
          className="w-full bg-purple-600 hover:bg-purple-700"
          disabled={!file || isUploading}
        >
          Convert to PowerPoint
        </Button>
      </div>

      {error && (
        <div className="mt-4 p-3 bg-red-900/30 border border-red-800 rounded-md flex items-center text-red-400">
          <AlertCircle className="h-5 w-5 mr-2 flex-shrink-0" />
          <p className="text-sm">{error}</p>
        </div>
      )}
    </div>
  )
}
