import { FileText, Wand2, Eye, Download } from "lucide-react"

export function HowItWorks() {
  const steps = [
    {
      icon: <FileText className="h-8 w-8 text-purple-400" />,
      title: "Upload Your PDF",
      description: "Upload any PDF document up to 5MB in size.",
    },
    {
      icon: <Wand2 className="h-8 w-8 text-purple-400" />,
      title: "AI Processing",
      description: "Our AI analyzes your PDF and converts it into a professional PowerPoint presentation.",
    },
    {
      icon: <Eye className="h-8 w-8 text-purple-400" />,
      title: "Preview Results",
      description: "Review the generated slides before making your purchase.",
    },
    {
      icon: <Download className="h-8 w-8 text-purple-400" />,
      title: "Download & Use",
      description: "Pay $2 and download your ready-to-use PowerPoint presentation.",
    },
  ]

  return (
    <div className="max-w-6xl mx-auto">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold mb-4">How It Works</h2>
        <p className="text-xl text-gray-400 max-w-2xl mx-auto">
          Transform your PDFs into stunning PowerPoint presentations in just a few simple steps
        </p>
      </div>

      <div className="grid md:grid-cols-4 gap-8">
        {steps.map((step, index) => (
          <div key={index} className="bg-gray-900/70 border border-gray-800 rounded-lg p-6 text-center">
            <div className="flex justify-center mb-4">
              <div className="w-16 h-16 rounded-full bg-purple-900/30 flex items-center justify-center">
                {step.icon}
              </div>
            </div>
            <h3 className="text-xl font-bold mb-2">{step.title}</h3>
            <p className="text-gray-400">{step.description}</p>
          </div>
        ))}
      </div>

      <div className="relative mt-12">
        <div className="hidden md:block absolute top-1/2 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-purple-500 to-transparent -translate-y-1/2 z-0" />
        <div className="hidden md:flex justify-between absolute top-1/2 left-[12.5%] right-[12.5%] -translate-y-1/2 z-10">
          {[1, 2, 3].map((_, index) => (
            <div key={index} className="w-4 h-4 rounded-full bg-purple-500" />
          ))}
        </div>
      </div>
    </div>
  )
}
