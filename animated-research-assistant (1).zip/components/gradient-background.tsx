"use client"

import { useEffect, useState } from "react"

interface GradientBackgroundProps {
  className?: string
}

export function GradientBackground({ className = "h-full w-full" }: GradientBackgroundProps) {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      // Calculate position as percentage of viewport
      const x = e.clientX / window.innerWidth
      const y = e.clientY / window.innerHeight
      setMousePosition({ x, y })
    }

    window.addEventListener("mousemove", handleMouseMove)
    return () => {
      window.removeEventListener("mousemove", handleMouseMove)
    }
  }, [])

  // Calculate gradient position based on mouse movement
  const gradientStyle = {
    background: `radial-gradient(circle at ${mousePosition.x * 100}% ${
      mousePosition.y * 100
    }%, rgba(120, 50, 255, 0.15), rgba(0, 0, 0, 0) 60%)`,
  }

  return (
    <div className={`${className} relative overflow-hidden`}>
      {/* Base background */}
      <div className="absolute inset-0 bg-black bg-grid-white/[0.02]" />

      {/* Animated gradient overlay */}
      <div className="absolute inset-0 transition-all duration-500 ease-in-out" style={gradientStyle} />

      {/* Subtle noise texture */}
      <div className="absolute inset-0 bg-noise opacity-20" />

      {/* Subtle glow at the top */}
      <div className="absolute top-0 left-0 right-0 h-[300px] bg-gradient-to-b from-purple-900/20 to-transparent" />
    </div>
  )
}
