"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Sparkles, Zap, Palette, Layout, FileText } from "lucide-react"

export function AIIntegration() {
  const [enhanceContent, setEnhanceContent] = useState(true)
  const [improveDesign, setImproveDesign] = useState(true)
  const [optimizeLayout, setOptimizeLayout] = useState(true)
  const [selectedModel, setSelectedModel] = useState("deepseek")

  return (
    <Card className="bg-gray-900/70 border border-gray-800">
      <CardHeader>
        <div className="flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-purple-400" />
          <CardTitle>AI Enhancement</CardTitle>
        </div>
        <CardDescription>Choose how AI will improve your presentation</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <Tabs defaultValue="deepseek" onValueChange={setSelectedModel}>
          <TabsList className="grid grid-cols-2">
            <TabsTrigger value="deepseek">DeepSeek</TabsTrigger>
            <TabsTrigger value="gemini">Gemini</TabsTrigger>
          </TabsList>
          <TabsContent value="deepseek" className="mt-4">
            <div className="text-sm text-gray-400 mb-4">
              DeepSeek excels at understanding complex documents and creating professional presentations with accurate
              content extraction.
            </div>
          </TabsContent>
          <TabsContent value="gemini" className="mt-4">
            <div className="text-sm text-gray-400 mb-4">
              Gemini is great for creative presentations with engaging visuals and modern design elements.
            </div>
          </TabsContent>
        </Tabs>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileText className="h-4 w-4 text-purple-400" />
              <Label htmlFor="enhance-content" className="cursor-pointer">
                <div>Enhance Content</div>
                <p className="text-xs text-gray-400">Improve text clarity and readability</p>
              </Label>
            </div>
            <Switch id="enhance-content" checked={enhanceContent} onCheckedChange={setEnhanceContent} />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Palette className="h-4 w-4 text-purple-400" />
              <Label htmlFor="improve-design" className="cursor-pointer">
                <div>Improve Design</div>
                <p className="text-xs text-gray-400">Enhance visual appeal with better colors and styles</p>
              </Label>
            </div>
            <Switch id="improve-design" checked={improveDesign} onCheckedChange={setImproveDesign} />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Layout className="h-4 w-4 text-purple-400" />
              <Label htmlFor="optimize-layout" className="cursor-pointer">
                <div>Optimize Layout</div>
                <p className="text-xs text-gray-400">Improve slide organization and structure</p>
              </Label>
            </div>
            <Switch id="optimize-layout" checked={optimizeLayout} onCheckedChange={setOptimizeLayout} />
          </div>
        </div>
      </CardContent>
      <CardFooter className="border-t border-gray-800 pt-4">
        <div className="w-full flex items-center justify-between">
          <div className="text-sm text-gray-400 flex items-center">
            <Zap className="h-4 w-4 mr-1 text-yellow-500" />
            AI-powered enhancements
          </div>
          <div className="text-sm font-medium text-purple-400">
            {selectedModel === "deepseek" ? "DeepSeek" : "Gemini"} AI
          </div>
        </div>
      </CardFooter>
    </Card>
  )
}
