import { Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export function Pricing() {
  const features = [
    "PDF to PowerPoint conversion",
    "Preserves graphs and charts",
    "Maintains formatting and layout",
    "Adds animations and transitions",
    "Supports images and media",
    "Preview before download",
    "Instant download after payment",
  ]

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold mb-4">Simple Pricing</h2>
        <p className="text-xl text-gray-400 max-w-2xl mx-auto">
          No subscriptions, no hidden fees. Just pay for what you need.
        </p>
      </div>

      <div className="bg-gray-900/70 border border-purple-500/30 rounded-lg p-8 shadow-lg shadow-purple-500/10">
        <div className="text-center mb-6">
          <div className="inline-block px-4 py-1 bg-purple-900/30 rounded-full text-purple-400 text-sm font-medium mb-4">
            Per Presentation
          </div>
          <div className="flex items-center justify-center">
            <span className="text-5xl font-bold">$2</span>
            <span className="text-gray-400 ml-2">/conversion</span>
          </div>
        </div>

        <div className="space-y-4 mb-8">
          {features.map((feature, index) => (
            <div key={index} className="flex items-center">
              <Check className="h-5 w-5 text-green-500 mr-3 flex-shrink-0" />
              <span>{feature}</span>
            </div>
          ))}
        </div>

        <Button className="w-full bg-purple-600 hover:bg-purple-700" size="lg" asChild>
          <Link href="/#">Try It Now</Link>
        </Button>

        <p className="text-center text-sm text-gray-400 mt-4">
          No account required. Upload, preview, and pay only if you're satisfied.
        </p>
      </div>
    </div>
  )
}
