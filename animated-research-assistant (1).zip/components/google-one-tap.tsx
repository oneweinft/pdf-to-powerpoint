"use client"

import { useEffect, useRef, useState } from "react"
import { useRouter } from "next/navigation"
import Script from "next/script"
import { createClient } from "@/utils/supabase/client"
import { toast } from "@/components/ui/use-toast"
import { generateNonce, hashNonce } from "@/utils/auth-utils"

interface GoogleOneTapProps {
  redirectUrl?: string
}

export default function GoogleOneTap({ redirectUrl = "/dashboard" }: GoogleOneTapProps) {
  const initialized = useRef(false)
  const router = useRouter()
  const supabase = createClient()
  const [nonce, setNonce] = useState<string>("")

  useEffect(() => {
    // Only initialize once
    if (initialized.current) return
    initialized.current = true

    // Generate a nonce for security
    const setupNonce = async () => {
      const newNonce = generateNonce()
      setNonce(newNonce)

      // Check if Google One Tap script is loaded
      if (typeof window !== "undefined" && window.google && window.google.accounts) {
        const hashedNonce = await hashNonce(newNonce)
        initializeGoogleOneTap(newNonce, hashedNonce)
      }
    }

    setupNonce()
  }, [redirectUrl])

  const initializeGoogleOneTap = (nonce: string, hashedNonce: string) => {
    if (!window.google || !window.google.accounts) {
      console.error("Google One Tap script not loaded")
      return
    }

    try {
      window.google.accounts.id.initialize({
        client_id: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID!,
        callback: (response) => handleCredentialResponse(response, nonce),
        auto_select: true,
        cancel_on_tap_outside: false,
        nonce: hashedNonce,
      })

      window.google.accounts.id.prompt((notification: any) => {
        if (notification.isNotDisplayed() || notification.isSkippedMoment()) {
          // One Tap is not displayed or was skipped
          // console.log(
          //   "One Tap not displayed or skipped:",
          //   notification.getNotDisplayedReason() || notification.getSkippedReason(),
          // )
        }
      })
    } catch (error) {
      // console.error("Error initializing Google One Tap:", error)
    }
  }

  const handleCredentialResponse = async (response: any, nonce: string) => {
    try {
      // Sign in with Supabase using the ID token
      const { data, error } = await supabase.auth.signInWithIdToken({
        provider: "google",
        token: response.credential,
        nonce: nonce,
      })

      if (error) {
        console.error("Authentication error:", error)
        toast({
          title: "Authentication failed",
          description: error.message || "Failed to sign in with Google",
          variant: "destructive",
        })
        return
      }

      if (data.user) {
        toast({
          title: "Signed in successfully",
          description: `Welcome ${data.user.user_metadata.full_name || data.user.email}!`,
        })
        router.push(redirectUrl)
        router.refresh()
      }
    } catch (error: any) {
      // console.error("Error handling Google One Tap response:", error)
      toast({
        title: "Authentication error",
        description: error.message || "An unexpected error occurred",
        variant: "destructive",
      })
    }
  }

  return (
    <Script
      src="https://accounts.google.com/gsi/client"
      strategy="afterInteractive"
      onLoad={() => {
        if (!initialized.current) {
          initialized.current = true
          const setupOnLoad = async () => {
            const newNonce = generateNonce()
            setNonce(newNonce)
            const hashedNonce = await hashNonce(newNonce)
            initializeGoogleOneTap(newNonce, hashedNonce)
          }
          setupOnLoad()
        }
      }}
    />
  )
}
