import { Star } from "lucide-react"

export function Testimonials() {
  const testimonials = [
    {
      name: "Sarah Johnson",
      role: "Marketing Director",
      content:
        "This tool saved me hours of work. I had a PDF report that needed to be presented to executives, and Death Works AI converted it into a stunning PowerPoint in minutes.",
      rating: 5,
    },
    {
      name: "Michael Chen",
      role: "Product Manager",
      content:
        "The quality of the conversion is impressive. All my charts and graphs were perfectly preserved, and the animations added a professional touch.",
      rating: 5,
    },
    {
      name: "Emily Rodriguez",
      role: "University Professor",
      content:
        "I use this tool to convert my research papers into presentations for my lectures. The $2 fee is well worth the time saved.",
      rating: 4,
    },
  ]

  return (
    <div className="max-w-6xl mx-auto">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold mb-4">What Our Users Say</h2>
        <p className="text-xl text-gray-400 max-w-2xl mx-auto">
          Join thousands of satisfied users who have transformed their PDFs
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-8">
        {testimonials.map((testimonial, index) => (
          <div key={index} className="bg-gray-900/70 border border-gray-800 rounded-lg p-6">
            <div className="flex mb-4">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`h-5 w-5 ${i < testimonial.rating ? "text-yellow-500 fill-yellow-500" : "text-gray-600"}`}
                />
              ))}
            </div>
            <p className="text-gray-300 mb-6">"{testimonial.content}"</p>
            <div>
              <p className="font-medium">{testimonial.name}</p>
              <p className="text-sm text-gray-400">{testimonial.role}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
