"use client"

import { useState } from "react"
import { ChevronDown } from "lucide-react"

interface FAQItemProps {
  question: string
  answer: string
}

function FAQItem({ question, answer }: FAQItemProps) {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <div className="border-b border-gray-800">
      <button className="flex justify-between items-center w-full py-4 text-left" onClick={() => setIsOpen(!isOpen)}>
        <span className="font-medium">{question}</span>
        <ChevronDown className={`h-5 w-5 transition-transform ${isOpen ? "transform rotate-180" : ""}`} />
      </button>
      <div className={`overflow-hidden transition-all ${isOpen ? "max-h-96 pb-4" : "max-h-0"}`}>
        <p className="text-gray-400">{answer}</p>
      </div>
    </div>
  )
}

export function FAQ() {
  const faqs = [
    {
      question: "How does the PDF to PowerPoint conversion work?",
      answer:
        "Our AI analyzes your PDF document, extracts text, images, charts, and other elements, and then recreates them in a PowerPoint presentation format. The AI also adds appropriate animations and transitions to make your presentation more engaging.",
    },
    {
      question: "What's the maximum file size I can upload?",
      answer:
        "Currently, we support PDF files up to 5MB in size. This limit allows us to process your files quickly while maintaining high quality in the conversion.",
    },
    {
      question: "How long does the conversion process take?",
      answer:
        "Most conversions are completed within 2-5 minutes, depending on the complexity and size of your PDF. You'll be able to preview the results before making your purchase.",
    },
    {
      question: "What payment methods do you accept?",
      answer:
        "We accept all major credit cards for the $2 per conversion fee. Payment is processed securely through our payment provider.",
    },
    {
      question: "Can I edit the PowerPoint after downloading?",
      answer:
        "Yes! The downloaded file is a standard PowerPoint (.pptx) file that you can edit using Microsoft PowerPoint or any compatible presentation software.",
    },
    {
      question: "Is my data secure?",
      answer:
        "We take data security seriously. Your uploaded PDFs and generated presentations are automatically deleted from our servers after 24 hours. We do not store your payment information.",
    },
  ]

  return (
    <div className="max-w-3xl mx-auto">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold mb-4">Frequently Asked Questions</h2>
        <p className="text-xl text-gray-400">Have questions? We've got answers.</p>
      </div>

      <div className="bg-gray-900/70 border border-gray-800 rounded-lg p-6">
        {faqs.map((faq, index) => (
          <FAQItem key={index} question={faq.question} answer={faq.answer} />
        ))}
      </div>
    </div>
  )
}
