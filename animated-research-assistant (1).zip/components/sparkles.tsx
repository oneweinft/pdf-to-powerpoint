"use client"

import type React from "react"
import { useRef, useEffect } from "react"
import { tsParticles } from "@tsparticles/engine"
import { loadFull } from "tsparticles"

interface SparklesCoreProps {
  id: string
  background: string
  minSize: number
  maxSize: number
  particleDensity: number
  className?: string
  particleColor: string
}

export const SparklesCore: React.FC<SparklesCoreProps> = ({
  id,
  background,
  minSize,
  maxSize,
  particleDensity,
  className,
  particleColor,
}) => {
  const particlesInit = useRef(false)

  useEffect(() => {
    if (particlesInit.current) return
    particlesInit.current = true

    const init = async () => {
      await loadFull(tsParticles)
    }

    init()
  }, [])

  useEffect(() => {
    const initParticles = async () => {
      await tsParticles.load(id, {
        background: {
          color: {
            value: background,
          },
        },
        fpsLimit: 60,
        interactivity: {
          events: {
            onClick: {
              enable: false,
              mode: "push",
            },
            onHover: {
              enable: false,
              mode: "repulse",
            },
            resize: true,
          },
          modes: {
            push: {
              quantity: 4,
            },
            repulse: {
              distance: 200,
              duration: 0.4,
            },
          },
        },
        particles: {
          color: {
            value: particleColor,
          },
          links: {
            color: particleColor,
            distance: 150,
            enable: false,
            opacity: 0.5,
            width: 1,
          },
          collisions: {
            enable: false,
          },
          move: {
            directions: "none",
            enable: true,
            outModes: {
              default: "bounce",
            },
            random: true,
            speed: 1,
            straight: false,
          },
          number: {
            density: {
              enable: true,
              area: particleDensity,
            },
            value: 80,
          },
          opacity: {
            value: 0.5,
          },
          shape: {
            type: "circle",
          },
          size: {
            value: { min: minSize, max: maxSize },
          },
        },
        detectRetina: true,
      })
    }

    initParticles()

    return () => {
      tsParticles.dom().forEach((container) => {
        if (container.id === id) container.destroy()
      })
    }
  }, [id, background, minSize, maxSize, particleDensity, particleColor])

  return <div id={id} className={className} />
}
