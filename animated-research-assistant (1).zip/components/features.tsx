import { Sparkles, BarChart3, Film, Music, Type, ImageIcon, Layers, Zap } from "lucide-react"

export function Features() {
  const features = [
    {
      icon: <BarChart3 className="h-6 w-6 text-purple-400" />,
      title: "Graphs & Charts",
      description: "Automatically converts PDF charts into editable PowerPoint graphs.",
    },
    {
      icon: <Film className="h-6 w-6 text-purple-400" />,
      title: "Animations",
      description: "Adds professional animations and transitions between slides.",
    },
    {
      icon: <Music className="h-6 w-6 text-purple-400" />,
      title: "Audio Support",
      description: "Preserves audio elements from your PDF in the PowerPoint.",
    },
    {
      icon: <Type className="h-6 w-6 text-purple-400" />,
      title: "Text Formatting",
      description: "Maintains text styles, fonts, and formatting from the original PDF.",
    },
    {
      icon: <ImageIcon className="h-6 w-6 text-purple-400" />,
      title: "Image Extraction",
      description: "Extracts and optimizes images for your presentation.",
    },
    {
      icon: <Layers className="h-6 w-6 text-purple-400" />,
      title: "Layout Preservation",
      description: "Maintains the structure and layout of your original document.",
    },
    {
      icon: <Zap className="h-6 w-6 text-purple-400" />,
      title: "Fast Processing",
      description: "Convert your PDF to PowerPoint in minutes, not hours.",
    },
    {
      icon: <Sparkles className="h-6 w-6 text-purple-400" />,
      title: "AI Enhancement",
      description: "Our AI improves the visual appeal of your presentation.",
    },
  ]

  return (
    <div className="max-w-6xl mx-auto">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold mb-4">Features</h2>
        <p className="text-xl text-gray-400 max-w-2xl mx-auto">
          Our AI-powered conversion preserves all the important elements of your PDF
        </p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        {features.map((feature, index) => (
          <div key={index} className="bg-gray-900/70 border border-gray-800 rounded-lg p-6">
            <div className="mb-4">{feature.icon}</div>
            <h3 className="text-lg font-bold mb-2">{feature.title}</h3>
            <p className="text-gray-400 text-sm">{feature.description}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
