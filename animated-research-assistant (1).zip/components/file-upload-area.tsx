"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Upload, File, X, Check, AlertCircle } from "lucide-react"
import { Progress } from "@/components/ui/progress"

interface FileUploadAreaProps {
  accept: string
  maxSize: number
  maxFiles?: number
  onFilesSelected: (files: File[]) => void
  label: string
  description: string
}

export function FileUploadArea({
  accept,
  maxSize,
  maxFiles = 1,
  onFilesSelected,
  label,
  description,
}: FileUploadAreaProps) {
  const [isDragging, setIsDragging] = useState(false)
  const [files, setFiles] = useState<File[]>([])
  const [error, setError] = useState<string | null>(null)
  const [uploading, setUploading] = useState(false)
  const [progress, setProgress] = useState(0)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }

  const handleDragLeave = () => {
    setIsDragging(false)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
    handleFiles(e.dataTransfer.files)
  }

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      handleFiles(e.target.files)
    }
  }

  const handleFiles = (fileList: FileList) => {
    setError(null)
    const newFiles: File[] = []
    const acceptedTypes = accept.split(",").map((type) => type.trim())

    Array.from(fileList).forEach((file) => {
      // Check file type
      const fileType = file.type
      const isAccepted = acceptedTypes.some((type) => {
        if (type.includes("*")) {
          const mainType = type.split("/")[0]
          return fileType.startsWith(`${mainType}/`)
        }
        return type === fileType
      })

      if (!isAccepted) {
        setError(`File type not accepted: ${file.name}`)
        return
      }

      // Check file size
      if (file.size > maxSize) {
        setError(`File too large: ${file.name}`)
        return
      }

      newFiles.push(file)
    })

    // Check max files
    if (files.length + newFiles.length > maxFiles) {
      setError(`You can upload a maximum of ${maxFiles} files`)
      return
    }

    if (newFiles.length > 0) {
      const updatedFiles = [...files, ...newFiles]
      setFiles(updatedFiles)
      onFilesSelected(updatedFiles)

      // Simulate upload progress
      simulateUpload()
    }
  }

  const simulateUpload = () => {
    setUploading(true)
    setProgress(0)

    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setUploading(false)
          return 100
        }
        return prev + 10
      })
    }, 200)
  }

  const removeFile = (index: number) => {
    const newFiles = [...files]
    newFiles.splice(index, 1)
    setFiles(newFiles)
    onFilesSelected(newFiles)
  }

  const triggerFileInput = () => {
    fileInputRef.current?.click()
  }

  return (
    <div className="w-full">
      <div
        className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors ${
          isDragging
            ? "border-purple-500 bg-purple-900/20"
            : files.length > 0
              ? "border-green-500 bg-green-900/10"
              : "border-gray-600 hover:border-gray-500 bg-gray-900/50 hover:bg-gray-800/50"
        }`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={files.length === 0 ? triggerFileInput : undefined}
        style={{ cursor: files.length === 0 ? "pointer" : "default" }}
      >
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileInputChange}
          accept={accept}
          className="hidden"
          multiple={maxFiles > 1}
        />

        {files.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-4">
            <Upload className="h-12 w-12 text-gray-400 mb-4" />
            <p className="text-xl font-medium mb-1">{label}</p>
            <p className="text-sm text-gray-400 mb-4">{description}</p>
            <Button
              variant="outline"
              onClick={(e) => {
                e.stopPropagation()
                triggerFileInput()
              }}
              className="border-purple-500 text-purple-400 hover:bg-purple-950"
            >
              Select Files
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {files.map((file, index) => (
              <div key={index} className="flex items-center justify-between bg-gray-800 p-3 rounded-md">
                <div className="flex items-center">
                  <File className="h-5 w-5 text-gray-400 mr-2" />
                  <div className="text-left">
                    <p className="text-sm font-medium truncate">{file.name}</p>
                    <p className="text-xs text-gray-400">{(file.size / 1024).toFixed(1)} KB</p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={(e) => {
                    e.stopPropagation()
                    removeFile(index)
                  }}
                  className="h-8 w-8 text-gray-400 hover:text-white"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ))}

            {uploading && (
              <div className="mt-4">
                <Progress value={progress} className="h-2 mb-2" />
                <p className="text-sm text-gray-400">Uploading... {progress}%</p>
              </div>
            )}

            {progress === 100 && !uploading && (
              <div className="flex items-center justify-center text-green-500 mt-2">
                <Check className="h-5 w-5 mr-2" />
                <span>Upload complete</span>
              </div>
            )}

            <Button
              variant="outline"
              onClick={triggerFileInput}
              className="mt-4 border-purple-500 text-purple-400 hover:bg-purple-950"
              disabled={files.length >= maxFiles}
            >
              {files.length < maxFiles ? "Add More Files" : "Maximum Files Reached"}
            </Button>
          </div>
        )}
      </div>

      {error && (
        <div className="mt-4 p-3 bg-red-900/30 border border-red-800 rounded-md flex items-center text-red-400">
          <AlertCircle className="h-5 w-5 mr-2 flex-shrink-0" />
          <p className="text-sm">{error}</p>
        </div>
      )}
    </div>
  )
}
